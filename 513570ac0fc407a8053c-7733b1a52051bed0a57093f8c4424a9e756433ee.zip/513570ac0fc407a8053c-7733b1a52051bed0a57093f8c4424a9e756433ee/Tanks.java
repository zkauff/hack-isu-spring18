/*
 * Copyright (c) 2013 midgardabc.com
 */
package lesson_3;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

/**
 * @version 3.0
 */
public class Tanks extends JPanel {

	int BF_WIDTH = 576;
	int BF_HEIGHT = 576;

	boolean COLORDED_MODE = false;

	int tankX = 5 * 64;
	int tankY = 5 * 64;

	int bulletX = -100;
	int bulletY = -100;

	int tankDirection = 1;

	int speed = 8;
	int bulletSpeed = 3;

	String[][] battleField = { { "B", "B", "B", "B", "B", "B", "B", "B", "B" },
			{ " ", " ", "B", " ", " ", " ", "B", " ", " " }, { "B", " ", " ", " ", "B", " ", " ", " ", "B" },
			{ "B", " ", " ", "B", "B", "B", " ", " ", "B" }, { " ", " ", " ", " ", " ", " ", " ", " ", " " },
			{ "B", "B", " ", " ", " ", " ", " ", "B", "B" }, { "B", "B", " ", " ", " ", " ", " ", "B", "B" },
			{ "B", "B", " ", "B", "B", "B", " ", "B", "B" }, { "B", "B", " ", "B", " ", "B", " ", "B", "B" } };

	/**
	 * Write your code here.
	 */

	void runTheGame() throws Exception {
//		moveRandom();
		 clean();
	}

	void clean() throws Exception {
		long time=System.currentTimeMillis();
		String random = String.valueOf(System.currentTimeMillis());
		int randomQuadrant = Integer.parseInt(random.substring(random.length() - 1));
		int quadrantX = randomQuadrant;
		int quadrantY = randomQuadrant;

//		int quadrantY = Integer.parseInt((getQuadrant(tankX, tankY).substring(0, 1)));
//		int quadrantX = Integer.parseInt((getQuadrant(tankX, tankY).substring(2)));

		if (quadrantY < 4) {
			moveToQuadrant(quadrantX + 1, 1);
		} else {
			moveToQuadrant(quadrantX + 1, 9);
		}
		for (int direction = 1; direction <= 4; direction++) {
			cleanLine(direction);
		}

		if (tankY == 0) {
			for (int i = 1; i < 9; i++) {
				move(2);
				for (int direction = 1; direction <= 4; direction++) {
					cleanLine(direction);
				}
			}
		} else {
			for (int i = 1; i <= 9; i++) {
				move(1);
				for (int direction = 1; direction <= 4; direction++) {
					cleanLine(direction);
				}
			}
		}
		System.out.println("Game Over");
		System.out.println(("Duration: " +(System.currentTimeMillis()-time)/1000 + " sek"));
	}

	void cleanLine(int direction) throws Exception {
		int quadrantY = Integer.parseInt((getQuadrant(tankX, tankY).substring(0, 1)));
		int quadrantX = Integer.parseInt((getQuadrant(tankX, tankY).substring(2)));
		turn(direction);
		if (direction == 3 && quadrantX >= 1) {
			for (int i = 1; i <= quadrantX; i++) {
				if (battleField[quadrantY][quadrantX - i] != " ") {
					fire();
				}
			}
		} else if (direction == 4 && quadrantX < 8) {
			for (int i = 1; i <= 8 - quadrantX; i++) {
				if (battleField[quadrantY][quadrantX + i] != " ") {
					fire();
				}
			}
		} else if (direction == 1 && quadrantY >= 1) {
			for (int i = 0; i <= quadrantY; i++) {
				if (battleField[quadrantY - i][quadrantX] != " ") {
					fire();
				}
			}
		} else if (direction == 2 && quadrantY < 8) {
			for (int i = 1; i <= 8 - quadrantY; i++) {
				if (battleField[quadrantY + i][quadrantX] != " ") {
					fire();
				}
			}
		}
	}

	boolean processInterception() {

		int quadrantY = Integer.parseInt((getQuadrant(bulletX, bulletY).substring(0, 1)));
		int quadrantX = Integer.parseInt((getQuadrant(bulletX, bulletY).substring(2)));
		if (quadrantX >= 0 && quadrantX < 9 && quadrantY >= 0 && quadrantY < 9) {
			if (battleField[quadrantY][quadrantX] != " ") {
				battleField[quadrantY][quadrantX] = " ";
				return true;
			}
		}
		return false;
	}

	public static String getQuadrant(int x, int y) {
		int numberX = x / 64;
		int numberY = y / 64;
		return (numberY + "_" + numberX);
	}

	/**
	 * - TANKS -
	 * 
	 * @param v
	 * @param h
	 * @throws Exception
	 */
	void moveToQuadrant(int v, int h) throws Exception {
		int coorX = Integer.parseInt(getQuadrantXY(v, h).substring(0, getQuadrantXY(v, h).indexOf("_")));
		int coorY = Integer.parseInt(getQuadrantXY(v, h).substring(getQuadrantXY(v, h).indexOf("_") + 1));
		if (tankX < coorX) {
			while (tankX < coorX) {
				move(4);
			}
		} else {
			while (tankX > coorX) {
				move(3);
			}
		}
		if (tankY < coorY) {
			while (tankY < coorY) {
				move(2);
			}
		} else {
			while (tankY > coorY) {
				move(1);
			}
		}
	}

	void turn(int direction) {
		tankDirection = direction;
	}

	void moveRandom() throws Exception {
		while (true) {
			String random = String.valueOf(System.currentTimeMillis());
			int directionRandom = Integer.parseInt(random.substring(random.length() - 1));
			if (directionRandom > 0 && directionRandom <= 9) {
				moveToQuadrant(directionRandom, directionRandom);
			}
		}
	}

	public static String getQuadrantXY(int v, int h) {
		return (v - 1) * 64 + "_" + (h - 1) * 64;
	}

	/**
	 * - TANKS -
	 * 
	 * @param direction
	 * @throws Exception
	 */
	void move(int direction) throws Exception {

		int step = 1;
		int left = 0;

		int quadrantY = Integer.parseInt((getQuadrant(tankX, tankY).substring(0, 1)));
		int quadrantX = Integer.parseInt((getQuadrant(tankX, tankY).substring(2)));

		turn(direction);

		if ((direction == 1 && quadrantY >= 1 && battleField[quadrantY - 1][quadrantX] != " ")
				|| (direction == 2 && quadrantY < 8 && battleField[quadrantY + 1][quadrantX] != " ")
				|| (direction == 3 && quadrantX >= 1 && battleField[quadrantY][quadrantX - 1] != " ")
				|| (direction == 4 && quadrantX < 8 && battleField[quadrantY][quadrantX + 1] != " ")) {
			fire();
		}

		while (left < 64) {
			if (direction == 1 && quadrantY >= 1) {
				tankY -= step;
			} else if (direction == 2 && quadrantY < 8) {
				tankY += step;
			} else if (direction == 3 && quadrantX >= 1) {
				tankX -= step;
			} else if (direction == 4 && quadrantX < 8) {
				tankX += step;
			}
			repaint();
			Thread.sleep(speed);
			left += step;
		}
	}

	void fire() throws Exception {

		int step = 1;
		int direction = tankDirection;

		bulletX = tankX + 25;
		bulletY = tankY + 25;

		while (bulletX > -25 && bulletX < 590 && bulletY > -25 && bulletY < 590) {
			if (direction == 1) {
				bulletY -= step;
				if (processInterception() == true) {
					processInterception();
					clearBullet();
				}
			} else if (direction == 2) {
				bulletY += step;
				if (processInterception() == true) {
					processInterception();
					clearBullet();
				}
			} else if (direction == 3) {
				bulletX -= step;
				if (processInterception() == true) {
					processInterception();
					clearBullet();
				}
			} else {
				bulletX += step;
				if (processInterception() == true) {
					processInterception();
					clearBullet();
				}
			}
			repaint();
			Thread.sleep(bulletSpeed);
		}
	}

	void clearBullet() {
		bulletX = -100;
		bulletY = -100;
	}

	// Magic bellow. Do not worry about this now, you will understand everything
	// in this course.
	// Please concentrate on your tasks only.

	public static void main(String[] args) throws Exception {
		Tanks bf = new Tanks();
		bf.runTheGame();
	}

	public Tanks() throws Exception {
		JFrame frame = new JFrame("BATTLE FIELD, DAY 2");
		frame.setLocation(550, 50);
		frame.setMinimumSize(new Dimension(BF_WIDTH + 14, BF_HEIGHT + 36));
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.getContentPane().add(this);
		frame.pack();
		frame.setVisible(true);
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		int i = 0;
		Color cc;
		for (int v = 0; v < 9; v++) {
			for (int h = 0; h < 9; h++) {
				if (COLORDED_MODE) {
					if (i % 2 == 0) {
						cc = new Color(252, 241, 177);
					} else {
						cc = new Color(233, 243, 255);
					}
				} else {
					cc = new Color(180, 180, 180);
				}
				i++;
				g.setColor(cc);
				g.fillRect(h * 64, v * 64, 64, 64);
			}
		}

		for (int j = 0; j < battleField.length; j++) {
			for (int k = 0; k < battleField.length; k++) {
				if (battleField[j][k].equals("B")) {
					String coordinates = getQuadrantXY(j + 1, k + 1);
					int separator = coordinates.indexOf("_");
					int y = Integer.parseInt(coordinates.substring(0, separator));
					int x = Integer.parseInt(coordinates.substring(separator + 1));
					g.setColor(new Color(0, 0, 255));
					g.fillRect(x, y, 64, 64);
				}
			}
		}

		g.setColor(new Color(255, 0, 0));
		g.fillRect(tankX, tankY, 64, 64);

		g.setColor(new Color(0, 255, 0));
		if (tankDirection == 1) {
			g.fillRect(tankX + 20, tankY, 24, 34);
		} else if (tankDirection == 2) {
			g.fillRect(tankX + 20, tankY + 30, 24, 34);
		} else if (tankDirection == 3) {
			g.fillRect(tankX, tankY + 20, 34, 24);
		} else {
			g.fillRect(tankX + 30, tankY + 20, 34, 24);
		}
		g.setColor(new Color(255, 255, 0));
		g.fillRect(bulletX, bulletY, 14, 14);
	}

}