package mmm;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import java.awt.Button;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Dialog.ModalExclusionType;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.Font;
import java.awt.Label;

public class gamer {

	private JFrame frame;
	private final Action action = new SwingAction();
	private final Action action_1 = new SwingAction_1();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gamer window = new gamer();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public gamer() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1280, 720);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewGame = new JButton("New Game");
		btnNewGame.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewGame.setBackground(new Color(70, 130, 180));
		btnNewGame.setBounds(548, 444, 184, 46);
		btnNewGame.setAction(action);
		frame.getContentPane().add(btnNewGame);
		
		JLabel lblitsjustaprankbroV = new JLabel("(#ITSJUSTAPRANKBRO!) v.0.0.1");
		lblitsjustaprankbroV.setForeground(Color.BLACK);
		lblitsjustaprankbroV.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblitsjustaprankbroV.setHorizontalAlignment(SwingConstants.CENTER);
		lblitsjustaprankbroV.setBounds(0, 345, 1280, 50);
		frame.getContentPane().add(lblitsjustaprankbroV);
		
		JLabel lblNewLabel = new JLabel("Nerdy Wizards Shooting Wonds(GONE DANGEROUS!)(GONE WRONG)");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(0, 261, 1280, 140);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("options");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton.setBackground(new Color(70, 130, 180));
		btnNewButton.setAction(action_1);
		btnNewButton.setBounds(565, 534, 150, 39);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_1.setBounds(0, 0, 1280, 720);
		lblNewLabel_1.setIcon(new ImageIcon(gamer.class.getResource("/download.jpg")));
		lblNewLabel_1.setLabelFor(frame);
		lblNewLabel_1.setBackground(new Color(0, 0, 0));
		frame.getContentPane().add(lblNewLabel_1);
		frame.getContentPane().setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{lblNewLabel_1, btnNewGame, lblNewLabel}));
	}

	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "New Game");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
	private class SwingAction_1 extends AbstractAction {
		public SwingAction_1() {
			putValue(NAME, "options");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
